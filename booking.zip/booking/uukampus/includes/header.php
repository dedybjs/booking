<?php
// Cek Sesi Login di setiap halaman yang dilindungi
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== TRUE) {
    // Jika tidak login, kembalikan ke login.
    // Gunakan $base_path yang didefinisikan di file utama (index.php)
    header('Location: ' . $base_path . 'login_admin.php');
    exit();
}

// Ambil data sesi untuk ditampilkan
$admin_nama = htmlspecialchars($_SESSION['nama_lengkap'] ?? 'Admin');
$admin_role = htmlspecialchars($_SESSION['role'] ?? 'N/A');

// CATATAN: Variabel $base_path HARUS didefinisikan di index.php sebelum include header.php
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin Aula UMP</title>
    
    <!-- Link CSS -->
    <!-- Semua link eksternal tidak perlu $base_path -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/2.0.8/css/dataTables.bootstrap5.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
    
    <!-- CSS KUSTOM: Menggunakan $base_path untuk memastikan path benar dari mana pun dipanggil -->
    <link href="<?php echo $base_path; ?>css/style_admin.css" rel="stylesheet">
</head>
<body>

<!-- 1. NAVBAR (Header Atas) -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top shadow">
    <div class="container-fluid">
        <!-- Tombol Toggle -->
        <button class="btn btn-dark me-2" id="sidebarToggle" type="button">
            <i class="fas fa-bars"></i>
        </button>
        <a class="navbar-brand" href="<?php echo $base_path; ?>index.php">
            <span class="d-none d-sm-inline">Admin Aula</span>
            <span class="d-inline d-sm-none">Menu</span>
        </a>
        
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <!-- Search Bar -->
            <form class="d-flex ms-lg-3 me-auto" action="<?php echo $base_path; ?>index.php?page=search" method="GET">
                <input type="hidden" name="page" value="search">
                <div class="input-group">
                    <input class="form-control form-control-sm" type="search" placeholder="Cari Data..." aria-label="Search" name="query">
                    <button class="btn btn-outline-secondary" type="submit"><i class="fas fa-search"></i></button>
                </div>
            </form>
            
            <!-- User Menu -->
            <ul class="navbar-nav mb-2 mb-lg-0">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fas fa-user-circle me-1"></i> <?php echo $admin_nama; ?>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                        <li><a class="dropdown-item" href="<?php echo $base_path; ?>index.php?page=profile">Profil</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item text-danger" href="<?php echo $base_path; ?>logout.php"><i class="fas fa-sign-out-alt me-2"></i> Logout</a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</nav>

<!-- 2. WRAPPER UTAMA: Ini adalah elemen yang dibutuhkan CSS Anda untuk layout -->
<div id="wrapper">
    <!-- Di sini akan di-include sidebar.php -->
