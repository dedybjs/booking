    <!-- FOOTER COPYRIGHT -->
    <footer class="text-center mt-4 pt-3 pb-3 border-top text-muted">
        <small>&copy; 2025 Admin Panel Aula UMP. All Rights Reserved.</small>
    </footer>

</div> <!-- End of #main-content -->

<!-- 4. FOOTER (Script) -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/2.0.8/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/2.0.8/js/dataTables.bootstrap5.min.js"></script>

<script>
    $(document).ready(function() {
        // Logika Toggle Sidebar
        $("#sidebarToggle").on("click", function (e) {
            e.preventDefault();
            // Toggle class 'toggled' pada elemen <body>
            $("body").toggleClass("toggled"); 
        });

        // Pastikan sidebar disembunyikan di mobile saat layar dimuat
        if ($(window).width() < 992) {
            $("body").addClass("toggled");
        }
    });
</script>

</body>
</html>