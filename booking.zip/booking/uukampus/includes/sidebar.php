
<nav id="sidebar"> 
    <ul class="nav flex-column pt-3">
        <div class="sidebar-title">MENU</div>
        <li class="nav-item">
            <!-- Link Dashboard seharusnya hanya ke index.php atau index.php?page=dashboard -->
            <a class="nav-link <?php echo ($current_page == 'halaman_admin') ? 'active' : ''; ?>" href="index.php?page=halaman_admin">
                <i class="fas fa-tachometer-alt me-2"></i> Dashboard
            </a>
        </li>
        <li class="nav-item">
            <!-- Menggunakan sistem routing index.php?page=... -->
            <a class="nav-link <?php echo ($current_page == 'data_booking') ? 'active' : ''; ?>" href="index.php?page=data_booking">
                <i class="fas fa-calendar-alt me-2"></i> Data Booking
            </a>
        </li>

        <div class="sidebar-title mt-3">MANAJEMEN</div>
        <li class="nav-item">
            <!-- Menggunakan sistem routing index.php?page=... -->
            <a class="nav-link <?php echo ($current_page == 'konfirmasi_dp') ? 'active' : ''; ?>" href="index.php?page=konfirmasi_dp">
                <i class="fas fa-money-check-alt me-2"></i> Konfirmasi DP
            </a>
        </li>
        <li class="nav-item">
            <!-- Menggunakan sistem routing index.php?page=... -->
            <a class="nav-link <?php echo ($current_page == 'pembayaran_lunas') ? 'active' : ''; ?>" href="index.php?page=pembayaran_lunas">
                <i class="fas fa-credit-card me-2"></i> Pembayaran Lunas
            </a>
        </li>
        <li class="nav-item">
            <!-- Menggunakan sistem routing index.php?page=... -->
            <a class="nav-link <?php echo ($current_page == 'data_user') ? 'active' : ''; ?>" href="index.php?page=data_user">
                <i class="fas fa-users me-2"></i> Data User
            </a>
        </li>

        <div class="sidebar-title mt-3">LAINNYA</div>
        <li class="nav-item">
            <!-- Menggunakan sistem routing index.php?page=... -->
            <a class="nav-link <?php echo ($current_page == 'laporan') ? 'active' : ''; ?>" href="index.php?page=laporan">
                <i class="fas fa-file-alt me-2"></i> Laporan
            </a>
        </li>
    </ul>
</nav>


<div id="main-content">