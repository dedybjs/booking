<?php
// login_admin.php
session_start();

// Cek jika sudah login, langsung redirect ke dashboard
if (isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === TRUE) {
    header('Location: index.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link href="css/css-login.css" rel="stylesheet">
</head>
<body>

<div class="login-card text-center">
    <div class="mb-4">
        <i class="fas fa-tools fa-3x text-primary"></i>
    </div>
    <h3 class="card-title mb-4">Admin Login</h3>
    <p class="text-muted mb-4">Akses Panel Pengelola Aula UMP</p>

    <?php 
    // Tampilkan notifikasi error
    if (isset($_SESSION['login_error'])) {
        echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
                ' . htmlspecialchars($_SESSION['login_error']) . '
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
              </div>';
        unset($_SESSION['login_error']); 
    }
    ?>
    
    <form action="handle_login.php" method="POST">
        <div class="mb-3 text-start">
            <label for="username" class="form-label fw-bold">Username</label>
            <div class="input-group">
                <span class="input-group-text"><i class="fas fa-user"></i></span>
                <input type="text" class="form-control" id="username" name="username" required>
            </div>
        </div>
        <div class="mb-4 text-start">
            <label for="password" class="form-label fw-bold">Password</label>
            <div class="input-group">
                <span class="input-group-text"><i class="fas fa-lock"></i></span>
                <input type="password" class="form-control" id="password" name="password" required>
            </div>
        </div>
        
        <button type="submit" class="btn btn-primary w-100 fw-bold py-2">
            <i class="fas fa-sign-in-alt me-2"></i> LOGIN
        </button>
    </form>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
