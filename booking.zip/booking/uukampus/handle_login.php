<?php
// handle_login.php (Di dalam folder uukampus/)
session_start();
// Path relatif ke file koneksi harus benar
include 'config/konnektingpipel.php'; 

// Cek ketersediaan objek koneksi $konektion
if (!isset($konektion) || $konektion->connect_error) { 
    $_SESSION['login_error'] = "Gagal terhubung ke database. Cek file koneksi.";
    // MENGGUNAKAN JALUR RELATIF
    header('Location: login_admin.php'); 
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $username = trim($_POST['username']); 
    $password = $_POST['password'];

    if ($username === '' || $password === '') {
        $_SESSION['login_error'] = "Username dan Password wajib diisi!";
        // MENGGUNAKAN JALUR RELATIF
        header("Location: login_admin.php");
        exit;
    }

    // Menggunakan Prepared Statement untuk keamanan
    $stmt = $konektion->prepare("SELECT id_admin, nama_lengkap, username, password, role 
                                 FROM admin 
                                 WHERE username = ? LIMIT 1");
    
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result(); 
    $stmt->close(); 

    if ($result->num_rows === 1) {
        $row = $result->fetch_assoc();

        // Verifikasi Password menggunakan hash
        if (password_verify($password, $row['password'])) {
            // Login sukses
            session_regenerate_id(true); 
            
            // Buat Variabel Sesi
            $_SESSION['admin_logged_in'] = TRUE;
            $_SESSION['id_admin']        = $row['id_admin'];
            $_SESSION['username']        = $row['username'];
            $_SESSION['nama_lengkap']    = $row['nama_lengkap'];
            $_SESSION['role']            = $row['role']; 

            $_SESSION['login_success'] = "Selamat datang kembali, " . $row['nama_lengkap'] . '!';

            // Redirect ke dashboard (Asumsi index.php ada di folder yang sama)
            header("Location: index.php"); 
            exit;
        } else {
            // Password salah
            $_SESSION['login_error'] = "Password yang Anda masukkan salah.";
            // MENGGUNAKAN JALUR RELATIF
            header("Location: login_admin.php");
            exit;
        }
    } else {
        // Username tidak ditemukan
        $_SESSION['login_error'] = "Username tidak ditemukan.";
        // MENGGUNAKAN JALUR RELATIF
        header("Location: login_admin.php");
        exit;
    }
} else {
    // Jika diakses tanpa method POST
    // MENGGUNAKAN JALUR RELATIF
    header("Location: login_admin.php");
    exit;
}
?>
