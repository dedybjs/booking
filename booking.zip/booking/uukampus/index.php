<?php
// index.php (di folder /uukampus/)
session_start();
// include file koneksi dan fungsi-fungsi lainnya
include 'config/konnektingpipel.php'; 

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== TRUE) {

    header('Location: login_admin.php');
    exit();
}

$baseurl = 'http://localhost/booking/uukampus';
error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));


// 3. Tentukan Halaman yang Diminta
$current_page = isset($_GET['page']) ? $_GET['page'] : 'halaman_admin'; // Default: 'halaman_admin'

// ------------------------------------
// MEMULAI TEMPLATE DASHBOARD
// ------------------------------------

// Memuat Header dan Sidebar
include 'includes/header.php';
// Anda sudah menambahkan div id="main-content" di includes/header.php atau kode HTML lainnya
include 'includes/sidebar.php';

// BARIS 31: Tambahkan titik koma di sini
echo'<div class="container-fluid pt-2 mt-3">'; 
// 4. LOGIKA ROUTING UTAMA (SWITCH/CASE lebih rapi daripada IF bertumpuk)

switch ($current_page) {
    case 'dashboard': // Dipertahankan untuk kompatibilitas
    case 'halaman_admin': // Case untuk nama halaman spesifik (jika berbeda dari dashboard)
        // File di root folder /uukampus/
        include 'halaman_admin.php'; 
        break;

    case 'data_booking':
        // File ini ada di subfolder pages/
        include 'pages/data_booking.php';
        break;

    case 'konfirmasi_dp':
        // File ini ada di subfolder pages/
        include 'pages/konfirmasi_dp.php'; 
        break;
        
    case 'pembayaran_lunas':
        // File ini ada di subfolder pages/
        include 'pages/pembayaran_lunas.php';
        break;

    case 'data_user':
        // File ini ada di subfolder pages/
        include 'pages/data_user.php';
        break;

    case 'laporan':
        // File ini ada di subfolder pages/
        include 'pages/laporan.php';
        break;
        
    default:
        // Halaman default jika 'page' tidak ditemukan
        include 'pages/404.php'; 
        break;
}

// Tambahkan titik koma di sini
echo'</div>'; 

// Memuat Footer
include 'includes/footer.php';

?>
