<?php
if (!function_exists('format_rupiah')) {
    function format_rupiah($angka) {
        return 'Rp ' . number_format($angka, 0, ',', '.');
    }
}

if (!function_exists('status_booking_badge_index')) {
    function status_booking_badge_index($status) {
        switch ($status) {
            case 'Confirmed':
                return '<span class="badge bg-success"><i class="fas fa-check-circle me-1"></i> Confirmed</span>';
            case 'Pending':
                return '<span class="badge bg-warning text-dark"><i class="fas fa-hourglass-half me-1"></i> Pending</span>';
            case 'Cancelled':
                return '<span class="badge bg-danger"><i class="fas fa-ban me-1"></i> Cancelled</span>';
            case 'Completed':
                return '<span class="badge bg-info"><i class="fas fa-trophy me-1"></i> Completed</span>';
            default:
                return '<span class="badge bg-secondary">' . $status . '</span>';
        }
    }
}

    global $konektion;

    // 1. Total Booking
    $query_total = "SELECT COUNT(booking_id) AS total FROM tbl_booking";
    $result_total = mysqli_query($konektion, $query_total);
    $data_total = mysqli_fetch_assoc($result_total);
    $total_booking = $data_total['total'] ?? 0;

    // 2. Menunggu DP/DP
    $query_pending = "SELECT COUNT(booking_id) AS pending FROM tbl_booking WHERE status_dp IN ('Menunggu', 'DP')";
    $result_pending = mysqli_query($konektion, $query_pending);
    $data_pending = mysqli_fetch_assoc($result_pending);
    $booking_pending = $data_pending['pending'] ?? 0;

    // 3. Booking Diterima (Status Booking = 'Confirmed')
    $query_confirmed = "SELECT COUNT(booking_id) AS confirmed FROM tbl_booking WHERE status_booking = 'Confirmed'";
    $result_confirmed = mysqli_query($konektion, $query_confirmed);
    $data_confirmed = mysqli_fetch_assoc($result_confirmed);
    $booking_confirmed = $data_confirmed['confirmed'] ?? 0;

    // 4. Pendapatan (Total Pembayaran Lunas) - ASUMSI kolom 'total_harga'
    $query_income = "SELECT SUM(total_harga) AS total_income FROM tbl_booking WHERE status_dp = 'Lunas'";
    $result_income = mysqli_query($konektion, $query_income);
    $data_income = mysqli_fetch_assoc($result_income);
    $total_income = $data_income['total_income'] ?? 0;

    $income_display = format_rupiah($total_income);

    if (isset($_SESSION['login_success'])) {
        echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="fas fa-check-circle me-2"></i> ' . htmlspecialchars($_SESSION['login_success']) . '
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
              </div>';
        unset($_SESSION['login_success']); // Hapus setelah ditampilkan
    }
?>

<!-- 3. KONTEN UTAMA -->


    <h1 class="h2 mb-4 text-dark"><i class="fas fa-tachometer-alt me-2"></i> Dashboard Ringkasan</h1>

    <div class="row g-4 mb-4">
        <!-- Card 1: Total Booking -->
        <div class="col-xl-3 col-md-6">
            <div class="card card-stats shadow-sm h-100 border-primary">
                <div class="card-body">
                    <div class="row align-items-center">
                        <div class="col-8">
                            <h5 class="card-title text-uppercase text-muted mb-0">TOTAL BOOKING</h5>
                            <span class="h2 fw-bold mb-0 text-dark"><?php echo $total_booking; ?></span>
                        </div>
                        <div class="col-4 text-end">
                            <i class="fas fa-calendar-check fa-3x text-primary"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Card 2: Menunggu DP -->
        <div class="col-xl-3 col-md-6">
            <div class="card card-stats shadow-sm h-100 border-warning">
                <div class="card-body">
                    <div class="row align-items-center">
                        <div class="col-8">
                            <h5 class="card-title text-uppercase text-muted mb-0">MENUNGGU DP/LUNAS</h5>
                            <span class="h2 fw-bold mb-0 text-dark"><?php echo $booking_pending; ?></span>
                        </div>
                        <div class="col-4 text-end">
                            <i class="fas fa-hourglass-half fa-3x text-warning"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Card 3: Booking Diterima -->
        <div class="col-xl-3 col-md-6">
            <div class="card card-stats shadow-sm h-100 border-success">
                <div class="card-body">
                    <div class="row align-items-center">
                        <div class="col-8">
                            <h5 class="card-title text-uppercase text-muted mb-0">BOOKING DITERIMA</h5>
                            <span class="h2 fw-bold mb-0 text-dark"><?php echo $booking_confirmed; ?></span>
                        </div>
                        <div class="col-4 text-end">
                            <i class="fas fa-check-circle fa-3x text-success"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Card 4: Pendapatan (Total) -->
        <div class="col-xl-3 col-md-6">
            <div class="card card-stats shadow-sm h-100 border-info">
                <div class="card-body">
                    <div class="row align-items-center">
                        <div class="col-8">
                            <h5 class="card-title text-uppercase text-muted mb-0">PENDAPATAN (LUNAS)</h5>
                            <span class="h4 fw-bold mb-0 text-dark"><?php echo $income_display; ?></span>
                        </div>
                        <div class="col-4 text-end">
                            <i class="fas fa-money-bill-wave fa-3x text-info"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
            
    <div class="row g-4">
        <!-- Tabel 10 Booking Terbaru -->
        <div class="col-lg-8">
            <div class="card shadow-sm h-100">
                <div class="card-header bg-white border-bottom fw-bold text-dark">
                    <i class="fas fa-clock me-2"></i> 10 Booking Terbaru
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover table-sm">
                            <thead>
                                <tr>
                                    <th>Kode</th>
                                    <th>Penyewa</th>
                                    <th>Tgl Acara</th>
                                    <th>Status</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                // Ambil 10 data terbaru
                                $query_latest = "SELECT booking_id, kode_booking, nama_penyewa, tgl_acara, status_booking 
                                                 FROM tbl_booking 
                                                 ORDER BY tgl_booking DESC 
                                                 LIMIT 10";
                                $result_latest = mysqli_query($konektion, $query_latest);
                                
                                if ($result_latest && mysqli_num_rows($result_latest) > 0) {
                                    while ($data = mysqli_fetch_assoc($result_latest)) {
                                        echo '<tr>';
                                        echo '<td>' . htmlspecialchars($data['kode_booking']) . '</td>';
                                        echo '<td>' . htmlspecialchars($data['nama_penyewa']) . '</td>';
                                        echo '<td>' . date('d F Y', strtotime($data['tgl_acara'])) . '</td>';
                                        // Panggil fungsi yang didefinisikan di awal file ini
                                        echo '<td>' . status_booking_badge_index($data['status_booking']) . '</td>'; 
                                        echo '<td><a href="pages/aksi_booking.php?act=detail&id=' . htmlspecialchars($data['booking_id']) . '" class="btn btn-sm btn-outline-primary"><i class="fas fa-eye"></i> Detail</a></td>';
                                        echo '</tr>';
                                    }
                                } else {
                                    echo '<tr><td colspan="5" class="text-center text-muted">Tidak ada data booking terbaru.</td></tr>';
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- Aktivitas Terbaru -->
        <div class="col-lg-4">
            <div class="card shadow-sm h-100">
                <div class="card-header bg-white border-bottom fw-bold text-dark">
                    <i class="fas fa-bell me-2"></i> Aktivitas Terbaru
                </div>
                <div class="card-body">
                    <ul class="list-group list-group-flush">
                        <!-- Data ini statis/dummy, Anda bisa menggantinya dengan data log dari DB -->
                        <li class="list-group-item">
                            <i class="fas fa-check text-success me-2"></i> Booking #BKG00128 dikonfirmasi oleh Admin.
                            <small class="d-block text-muted">2 jam yang lalu</small>
                        </li>
                        <li class="list-group-item">
                            <i class="fas fa-money-bill-wave text-info me-2"></i> Pembayaran Lunas dari Aulia (BKG00127) masuk.
                            <small class="d-block text-muted">Kemarin</small>
                        </li>
                        <li class="list-group-item">
                            <i class="fas fa-user-plus text-primary me-2"></i> User baru mendaftar: Budi Santoso.
                            <small class="d-block text-muted">2 hari yang lalu</small>
                        </li>
                        <li class="list-group-item">
                            <i class="fas fa-ban text-danger me-2"></i> Booking #BKG00120 dibatalkan.
                            <small class="d-block text-muted">3 hari yang lalu</small>
                        </li>
                    </ul>
                    <div class="text-center mt-3">
                        <a href="pages/laporan.php" class="btn btn-sm btn-outline-secondary">Lihat Semua Aktivitas</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
<!-- 3. KONTEN UTAMA -->