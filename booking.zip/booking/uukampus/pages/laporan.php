<!-- pages/laporan.php -->
<div class="card shadow-lg border-0">
    <div class="card-header bg-gradient-primary text-white py-3">
        <h4 class="mb-0 fw-bold"><i class="fas fa-file-alt me-2"></i> Laporan Keuangan & Data Booking</h4>
    </div>
    <div class="card-body p-4">
        <p class="text-muted">Gunakan form di bawah ini untuk menghasilkan laporan yang spesifik berdasarkan rentang waktu atau kategori.</p>
        
        <form method="GET" action="index.php">
            <!-- Hidden input untuk memastikan routing tetap ke halaman laporan setelah submit -->
            <input type="hidden" name="page" value="laporan"> 
            
            <div class="row g-3 mb-4 p-3 border rounded report-filter-area">
                <div class="col-lg-3 col-md-6">
                    <label for="tanggal_awal" class="form-label fw-semibold">Tanggal Awal</label>
                    <input type="date" class="form-control form-control-sm custom-input" id="tanggal_awal" name="tanggal_awal" required>
                </div>
                <div class="col-lg-3 col-md-6">
                    <label for="tanggal_akhir" class="form-label fw-semibold">Tanggal Akhir</label>
                    <input type="date" class="form-control form-control-sm custom-input" id="tanggal_akhir" name="tanggal_akhir" required>
                </div>
                <div class="col-lg-3 col-md-6">
                    <label for="jenis_laporan" class="form-label fw-semibold">Jenis Laporan</label>
                    <select class="form-select form-select-sm custom-input" id="jenis_laporan" name="jenis_laporan">
                        <option value="semua" selected>Semua Booking</option>
                        <option value="lunas">Hanya Lunas</option>
                        <option value="dp">Hanya DP</option>
                    </select>
                </div>
                <div class="col-lg-3 col-md-6 d-flex align-items-end">
                    <button type="submit" class="btn btn-primary w-100 btn-sm shadow-sm report-button">
                        <i class="fas fa-search me-1"></i> Generate Laporan
                    </button>
                </div>
            </div>
        </form>

        <hr class="mt-4 mb-4">

        <h5 class="mb-3 text-secondary">Hasil Laporan <span class="badge bg-primary report-count-badge">0 Data Ditemukan</span></h5>
        
        <?php
        // Logika PHP untuk mengambil dan menampilkan data laporan akan ditempatkan di sini
        // Misalnya:
        // if (isset($_GET['tanggal_awal'])) {
        //     // Tampilkan tabel hasil laporan
        // } else {
        ?>
        <div class="alert alert-info border-0 shadow-sm" role="alert">
            <i class="fas fa-filter me-1"></i> Silakan gunakan filter di atas dan klik **Generate Laporan** untuk menampilkan data.
        </div>
        <?php
        // }
        ?>

        <!-- Area untuk Tabel Laporan akan ditempatkan di sini -->
        <div id="report-table-area">
            <!-- Contoh struktur tabel yang akan dimuat -->
            <!-- <table class="table table-hover report-table">...</table> -->
        </div>

    </div>
</div>
<style>
    /* Custom style untuk gradient header (sesuaikan dengan Bootstrap Anda) */
    .bg-gradient-primary {
        background: #2c3e50; /* Warna fallback dari sidebar */
        background: linear-gradient(90deg, #3498db 0%, #2980b9 100%);
    }

    /* Gaya untuk Area Filter */
    .report-filter-area {
        background-color: #ecf0f1; /* Latar belakang abu-abu muda */
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
    }
    
    /* Gaya untuk Input dan Select */
    .custom-input {
        border-radius: 5px;
        border: 1px solid #bdc3c7;
        transition: border-color 0.2s;
    }
    .custom-input:focus {
        border-color: #3498db;
        box-shadow: 0 0 0 0.25rem rgba(52, 152, 219, 0.25); /* Shadow biru muda */
    }

    /* Gaya untuk Tombol Generate */
    .report-button {
        transition: background-color 0.2s, transform 0.2s;
        background-color: #3498db;
        border-color: #3498db;
    }
    .report-button:hover {
        background-color: #2980b9;
        border-color: #2980b9;
        transform: translateY(-1px);
    }

    /* Gaya untuk Badge Jumlah Data */
    .report-count-badge {
        font-size: 0.85rem;
        padding: 0.4em 0.8em;
        border-radius: 50px;
        font-weight: 600;
        background-color: #95a5a6 !important; /* Warna abu-abu yang lebih netral */
    }

    /* Gaya untuk Tabel Laporan (Persiapan) */
    .report-table {
        margin-top: 15px;
        border-radius: 8px;
        overflow: hidden; /* Penting untuk rounded corner di tabel */
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }
    .report-table th {
        background-color: #f1f1f1;
        font-weight: 700;
        color: #34495e;
    }
    .report-table tbody tr:hover {
        background-color: #f7f9fc;
        cursor: pointer;
    }
</style>
