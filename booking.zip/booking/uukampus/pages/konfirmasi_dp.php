<?php 

// Include fungsi badge (jika belum didefinisikan di header)
function status_dp_badge($status) {
    switch ($status) {
        case 'Lunas': return '<span class="badge bg-success">Lunas</span>';
        case 'Menunggu': return '<span class="badge bg-warning text-dark">Menunggu</span>';
        case 'Ditolak': return '<span class="badge bg-danger">Ditolak</span>';
        default: return '<span class="badge bg-secondary">N/A</span>';
    }
}

// TAMPILKAN NOTIFIKASI
if (isset($_SESSION['notif'])) {
    $notif = $_SESSION['notif'];
    echo '<div class="alert alert-' . htmlspecialchars($notif['type']) . ' alert-dismissible fade show" role="alert">' . $notif['pesan'] . '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button></div>';
    unset($_SESSION['notif']); 
}

?>

<h1 class="h2 mb-4 text-dark"><i class="fas fa-user-check me-2"></i> Konfirmasi Pembayaran DP</h1>

<div class="card shadow-sm">
    <div class="card-header bg-warning text-dark fw-bold">
        Daftar Booking Menunggu Verifikasi Bukti Transfer
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table id="tableKonfirmasiDP" class="table table-striped table-hover datatable-custom" style="width:100%">
                <thead>
                    <tr>
                        <th>Kode</th>
                        <th>Penyewa</th>
                        <th>Tgl Acara</th>
                        <th>Total Harga</th>
                        <th>Bukti Transfer</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    // Query untuk mengambil data yang status_dp nya 'Menunggu' DAN memiliki bukti_transfer
                    // Untuk saat ini, kita hanya filter berdasarkan 'Menunggu' karena bukti transfer mungkin belum diupload
                    $query_dp = "SELECT * FROM tbl_booking WHERE status_dp = 'Menunggu' ORDER BY tgl_booking ASC";
                    $result_dp = mysqli_query($konektion, $query_dp);

                    if (mysqli_num_rows($result_dp) > 0) {
                        while ($data = mysqli_fetch_assoc($result_dp)) {
                            $tanggal_format = date('d F Y', strtotime($data['tgl_acara']));
                            $harga_format = 'Rp ' . number_format($data['total_harga'], 0, ',', '.');
                            
                            // Logika Tampilan Bukti Transfer
                            $bukti_transfer_html = '<span class="badge bg-secondary">Belum Upload</span>';
                            $bukti_transfer_link = 'javascript:void(0)';
                            
                            if (!empty($data['bukti_transfer'])) {
                                $bukti_transfer_link = '../uploads/bukti_dp/' . htmlspecialchars($data['bukti_transfer']); // Asumsi path
                                $bukti_transfer_html = '<a href="' . $bukti_transfer_link . '" target="_blank" class="text-primary fw-bold"><i class="fas fa-file-image me-1"></i> Lihat Bukti</a>';
                            }

                            echo '<tr>';
                            echo '<td>' . htmlspecialchars($data['kode_booking']) . '</td>';
                            echo '<td>' . htmlspecialchars($data['nama_penyewa']) . '</td>';
                            echo '<td>' . $tanggal_format . '</td>';
                            echo '<td>' . $harga_format . '</td>';
                            echo '<td>' . $bukti_transfer_html . '</td>';
                            echo '<td>';
                            
                            // Tombol Aksi Konfirmasi
                            echo '<a href="proses_konfirmasi.php?act=terima&id=' . $data['booking_id'] . '" class="btn btn-sm btn-success me-1" onclick="return confirm(\'Konfirmasi pembayaran untuk ' . htmlspecialchars($data['kode_booking']) . ' sebagai LUNAS?\')"><i class="fas fa-check"></i> Terima</a>';
                            echo '<a href="proses_konfirmasi.php?act=tolak&id=' . $data['booking_id'] . '" class="btn btn-sm btn-danger" onclick="return confirm(\'Tolak pembayaran untuk ' . htmlspecialchars($data['kode_booking']) . '? Status DP akan menjadi Ditolak.\')"><i class="fas fa-times"></i> Tolak</a>';
                            
                            echo '</td>';
                            echo '</tr>';
                        }
                    } else {
                        echo '<tr><td colspan="6" class="text-center">Tidak ada booking yang menunggu konfirmasi DP.</td></tr>';
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
