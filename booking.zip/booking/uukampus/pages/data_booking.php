<?php


if (!function_exists('format_rupiah')) {
  function format_rupiah($angka) {
    return 'Rp ' . number_format($angka, 0, ',', '.');
  }
}

if (!function_exists('status_booking_badge_data')) {
  function status_booking_badge_data($status) {
    switch ($status) {
      case 'Confirmed':
        return '<span class="badge bg-success"><i class="fas fa-check-circle me-1"></i> Confirmed</span>';
      case 'Pending':
        return '<span class="badge bg-warning text-dark"><i class="fas fa-hourglass-half me-1"></i> Pending</span>';
      case 'Cancelled':
        return '<span class="badge bg-danger"><i class="fas fa-ban me-1"></i> Cancelled</span>';
      case 'Completed':
        return '<span class="badge bg-info"><i class="fas fa-trophy me-1"></i> Completed</span>';
      default:
        return '<span class="badge bg-secondary">' . $status . '</span>';
    }
  }
}

?>



  <h1 class="h2 mb-4 text-dark"><i class="fas fa-calendar-alt me-2"></i> Data Seluruh Booking</h1>

  <div class="card shadow-sm mb-4">
    <div class="card-header bg-white border-bottom fw-bold text-dark">
      Tabel Data Booking Aula
    </div>
    <div class="card-body">
      <div class="table-responsive">
        <table id="tabelDataBooking" class="table table-striped table-hover" style="width:100%">
          <thead>
            <tr>
              <th>No.</th>
              <th>Kode Booking</th>
              <th>Penyewa</th>
              <th>Tgl Acara</th>
              <th>Status Booking</th>
              <th>Status DP</th>
              <th>Total Harga</th>
              <th>Aksi</th>
            </tr>
          </thead>
          <tbody>
            <?php
            // --- PHP MOCK DATA (GANTIKAN DENGAN QUERY ASLI) ---
            $dummy_data = [
              ['booking_id' => 101, 'kode_booking' => 'A1001', 'nama_penyewa' => 'Andi Susanto', 'tgl_acara' => '2024-10-25', 'status_booking' => 'Confirmed', 'status_dp' => 'Lunas', 'total_harga' => 15000000],
              ['booking_id' => 102, 'kode_booking' => 'A1002', 'nama_penyewa' => 'Budi Raharjo', 'tgl_acara' => '2024-11-10', 'status_booking' => 'Pending', 'status_dp' => 'Menunggu', 'total_harga' => 22000000],
              ['booking_id' => 103, 'kode_booking' => 'A1003', 'nama_penyewa' => 'Citra Dewi', 'tgl_acara' => '2024-09-01', 'status_booking' => 'Completed', 'status_dp' => 'DP', 'total_harga' => 18000000],
              ['booking_id' => 104, 'kode_booking' => 'A1004', 'nama_penyewa' => 'Dewi Sartika', 'tgl_acara' => '2024-12-15', 'status_booking' => 'Cancelled', 'status_dp' => 'Lunas', 'total_harga' => 10000000],
            ];
            $data_to_iterate = $dummy_data; 
            // --- END MOCK DATA ---

            $no = 1;
            if (!empty($data_to_iterate)) {
              foreach ($data_to_iterate as $data) {
                $status_dp_badge = '';
                if ($data['status_dp'] == 'Lunas') {
                  $status_dp_badge = '<span class="badge bg-primary"><i class="fas fa-cash-register me-1"></i> Lunas</span>';
                } elseif ($data['status_dp'] == 'DP') {
                  $status_dp_badge = '<span class="badge bg-info text-dark"><i class="fas fa-money-bill-wave me-1"></i> DP</span>';
                } else {
                  $status_dp_badge = '<span class="badge bg-secondary"><i class="fas fa-clock me-1"></i> Menunggu</span>';
                }
                
                echo '<tr>';
                echo '<td>' . $no++ . '</td>';
                echo '<td>' . htmlspecialchars($data['kode_booking']) . '</td>';
                echo '<td>' . htmlspecialchars($data['nama_penyewa']) . '</td>';
                echo '<td>' . date('d F Y', strtotime($data['tgl_acara'])) . '</td>';
                echo '<td>' . status_booking_badge_data($data['status_booking']) . '</td>';
                echo '<td>' . $status_dp_badge . '</td>';
                echo '<td>' . format_rupiah($data['total_harga']) . '</td>';
                
                echo '<td>
                      <a href="aksi_booking.php?act=detail&id=' . htmlspecialchars($data['booking_id']) . '" class="btn btn-sm btn-outline-primary me-1" title="Detail"><i class="fas fa-eye"></i></a>
                      <a href="aksi_booking.php?act=edit&id=' . htmlspecialchars($data['booking_id']) . '" class="btn btn-sm btn-outline-warning me-1" title="Edit"><i class="fas fa-edit"></i></a>
                      <button type="button" class="btn btn-sm btn-outline-danger btn-delete" 
                        data-id="' . htmlspecialchars($data['booking_id']) . '" 
                        data-kode="' . htmlspecialchars($data['kode_booking']) . '"
                        title="Hapus"><i class="fas fa-trash-alt"></i></button>
                      </td>';
                echo '</tr>';
              }
            } else {
              echo '<tr><td colspan="8" class="text-center text-muted">Tidak ada data booking tersedia.</td></tr>';
            }
            ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

<!-- 3. KONTEN UTAMA -->
