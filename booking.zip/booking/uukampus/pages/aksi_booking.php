<?php
include '../includes/header.php'; 
include '../config/konnektingpipel.php';

// Ambil aksi dari URL
$act = isset($_GET['act']) ? $_GET['act'] : 'list';
$id  = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$title = "";
$data = null; 

// Logic untuk Edit/Detail
if ($id > 0 && ($act == 'edit' || $act == 'detail')) {
    // Ganti nama tabel dan kolom ID
    $query = "SELECT * FROM tbl_booking WHERE booking_id = $id";
    $result = mysqli_query($konektion, $query);
    if (mysqli_num_rows($result) > 0) {
        $data = mysqli_fetch_assoc($result);
    } else {
        header('Location: data_booking.php');
        exit();
    }
}

// ... (Menentukan Judul Halaman tetap sama)

// Tambahkan definisi fungsi status_booking_badge dan status_dp_badge di sini jika belum ada
// (atau pastikan sudah di-include dari data_booking.php, tapi untuk form lebih aman didefinisikan)

?>

<h1 class="h2 mb-4 text-dark"><i class="<?= $icon ?> me-2"></i> <?= $title ?></h1>

<div class="card shadow-sm mb-5">
    <div class="card-header bg-primary text-white fw-bold">
        Informasi Booking
    </div>
    <div class="card-body">
        <?php if ($act == 'detail'): ?>
            
            <div class="row mb-3">
                <div class="col-md-4 fw-bold">Kode Booking</div>
                <div class="col-md-8"><?= htmlspecialchars($data['kode_booking']) ?></div>
            </div>
            <div class="row mb-3">
                <div class="col-md-4 fw-bold">Penyewa</div>
                <div class="col-md-8"><?= htmlspecialchars($data['nama_penyewa']) ?> (Kontak: <?= htmlspecialchars($data['penyewa_kontak_wa']) ?>)</div>
            </div>
            <div class="row mb-3">
                <div class="col-md-4 fw-bold">Alamat Penyewa</div>
                <div class="col-md-8"><?= nl2br(htmlspecialchars($data['penyewa_alamat'])) ?></div>
            </div>
            <div class="row mb-3">
                <div class="col-md-4 fw-bold">Acara</div>
                <div class="col-md-8"><?= htmlspecialchars($data['jenis_acara']) ?></div>
            </div>
            <div class="row mb-3">
                <div class="col-md-4 fw-bold">Tanggal Acara</div>
                <div class="col-md-8"><?= date('d F Y', strtotime($data['tgl_acara'])) ?></div>
            </div>
            <div class="row mb-3">
                <div class="col-md-4 fw-bold">Waktu Acara</div>
                <div class="col-md-8"><?= date('H:i', strtotime($data['waktu_mulai'])) ?> - <?= date('H:i', strtotime($data['waktu_selesai'])) ?></div>
            </div>
            <div class="row mb-3">
                <div class="col-md-4 fw-bold">Status Booking</div>
                <div class="col-md-8"><?= status_booking_badge($data['status_booking']) ?></div>
            </div>
            <div class="row mb-3">
                <div class="col-md-4 fw-bold">Total Harga</div>
                <div class="col-md-8">Rp <?= number_format($data['total_harga'], 0, ',', '.') ?></div>
            </div>
            <div class="row mb-3">
                <div class="col-md-4 fw-bold">Notes Admin</div>
                <div class="col-md-8"><?= nl2br(htmlspecialchars($data['notes_admin'])) ?: 'Tidak ada catatan.' ?></div>
            </div>
            
            <a href="data_booking.php" class="btn btn-secondary mt-3"><i class="fas fa-chevron-left me-2"></i> Kembali</a>
            
        <?php else: ?>

            <form action="proses_booking.php?act=<?= $act ?>" method="POST">
                <?php if($act == 'edit'): ?>
                    <input type="hidden" name="booking_id" value="<?= $id ?>"> <div class="mb-3">
                        <label class="form-label">Kode Booking</label>
                        <input type="text" class="form-control" value="<?= htmlspecialchars($data['kode_booking']) ?>" disabled>
                    </div>
                <?php endif; ?>

                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="nama_penyewa" class="form-label">Nama Penyewa</label>
                        <input type="text" class="form-control" id="nama_penyewa" name="nama_penyewa" value="<?= $data ? htmlspecialchars($data['nama_penyewa']) : '' ?>" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="penyewa_kontak_wa" class="form-label">Kontak WA Penyewa</label>
                        <input type="text" class="form-control" id="penyewa_kontak_wa" name="penyewa_kontak_wa" value="<?= $data ? htmlspecialchars($data['penyewa_kontak_wa']) : '' ?>" required>
                    </div>
                </div>
                
                <div class="mb-3">
                    <label for="penyewa_alamat" class="form-label">Alamat Penyewa</label>
                    <textarea class="form-control" id="penyewa_alamat" name="penyewa_alamat" rows="3"><?= $data ? htmlspecialchars($data['penyewa_alamat']) : '' ?></textarea>
                </div>

                <div class="row">
                    <div class="col-md-4 mb-3">
                        <label for="tgl_acara" class="form-label">Tanggal Acara</label>
                        <input type="date" class="form-control" id="tgl_acara" name="tgl_acara" value="<?= $data ? htmlspecialchars($data['tgl_acara']) : '' ?>" required>
                    </div>
                    <div class="col-md-4 mb-3">
                        <label for="waktu_mulai" class="form-label">Waktu Mulai</label>
                        <input type="time" class="form-control" id="waktu_mulai" name="waktu_mulai" value="<?= $data ? htmlspecialchars($data['waktu_mulai']) : '' ?>" required>
                    </div>
                    <div class="col-md-4 mb-3">
                        <label for="waktu_selesai" class="form-label">Waktu Selesai</label>
                        <input type="time" class="form-control" id="waktu_selesai" name="waktu_selesai" value="<?= $data ? htmlspecialchars($data['waktu_selesai']) : '' ?>" required>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="jenis_acara" class="form-label">Jenis Acara</label>
                        <input type="text" class="form-control" id="jenis_acara" name="jenis_acara" value="<?= $data ? htmlspecialchars($data['jenis_acara']) : '' ?>" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="total_harga" class="form-label">Total Harga (Rp)</label>
                        <input type="number" class="form-control" id="total_harga" name="total_harga" value="<?= $data ? htmlspecialchars($data['total_harga']) : '' ?>" required>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="status_dp" class="form-label">Status Pembayaran DP</label>
                        <select class="form-select" id="status_dp" name="status_dp" required>
                            <?php 
                                $status_options = ['Menunggu', 'Lunas', 'Ditolak'];
                                $current_status = $data ? $data['status_dp'] : 'Menunggu';
                                foreach ($status_options as $opt) {
                                    $selected = ($opt == $current_status) ? 'selected' : '';
                                    echo "<option value=\"$opt\" $selected>$opt</option>";
                                }
                            ?>
                        </select>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="status_booking" class="form-label">Status Booking</label>
                        <select class="form-select" id="status_booking" name="status_booking" required>
                            <?php 
                                $status_options = ['Pending', 'Confirmed', 'Cancelled', 'Completed'];
                                $current_status = $data ? $data['status_booking'] : 'Pending';
                                foreach ($status_options as $opt) {
                                    $selected = ($opt == $current_status) ? 'selected' : '';
                                    echo "<option value=\"$opt\" $selected>$opt</option>";
                                }
                            ?>
                        </select>
                    </div>
                </div>
                
                <div class="mb-3">
                    <label for="notes_admin" class="form-label">Notes Admin</label>
                    <textarea class="form-control" id="notes_admin" name="notes_admin" rows="3"><?= $data ? htmlspecialchars($data['notes_admin']) : '' ?></textarea>
                </div>
                
                <button type="submit" class="btn btn-success"><i class="fas fa-save me-2"></i> Simpan Data</button>
                <a href="data_booking.php" class="btn btn-secondary"><i class="fas fa-undo me-2"></i> Batal</a>
            </form>

        <?php endif; ?>
    </div>
</div>

<?php 
include '../includes/footer.php'; 
?>