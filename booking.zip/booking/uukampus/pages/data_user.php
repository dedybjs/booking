<?php 
include '../includes/header.php'; 
?>

<h1 class="h2 mb-4 text-dark"><i class="fas fa-users-cog me-2"></i> Data User</h1>

<div class="card shadow-sm">
    <div class="card-header bg-info text-white fw-bold">
        Daftar Pengguna Sistem Penyewaan Aula
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table id="tableDataUser" class="table table-striped table-hover datatable-custom" style="width:100%">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nama</th>
                        <th>Email</th>
                        <th>Role</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>1</td>
                        <td>Admin Utama</td>
                        <td>admin@ump.ac.id</td>
                        <td><span class="badge bg-danger">Super Admin</span></td>
                        <td><span class="badge bg-success">Aktif</span></td>
                        <td><button class="btn btn-sm btn-warning text-white"><i class="fas fa-edit"></i> Edit</button></td>
                    </tr>
                    <tr>
                        <td>2</td>
                        <td>Joko Susilo</td>
                        <td>joko.susilo@gmail.com</td>
                        <td><span class="badge bg-primary">Klien</span></td>
                        <td><span class="badge bg-success">Aktif</span></td>
                        <td><button class="btn btn-sm btn-warning text-white"><i class="fas fa-edit"></i> Edit</button></td>
                    </tr>
                    <tr>
                        <td>3</td>
                        <td>Ani Nurhayati</td>
                        <td>ani.nh@yahoo.co.id</td>
                        <td><span class="badge bg-primary">Klien</span></td>
                        <td><span class="badge bg-secondary">Nonaktif</span></td>
                        <td><button class="btn btn-sm btn-warning text-white"><i class="fas fa-edit"></i> Edit</button></td>
                    </tr>
                    </tbody>
            </table>
        </div>
    </div>
</div>

<?php 
include '../includes/footer.php'; 
?>