<!-- pages/pembayaran_lunas.php -->
<div class="card shadow-sm">
    <div class="card-header bg-success text-white">
        <h4 class="mb-0"><i class="fas fa-credit-card me-2"></i> Data Pembayaran Lunas</h4>
    </div>
    <div class="card-body">
        <p class="text-muted">Ini adalah area untuk menampilkan dan mengelola data booking yang pembayarannya sudah dilunasi secara penuh.</p>
        
        <!-- Contoh Struktur Tabel Sementara -->
        <div class="table-responsive">
            <table class="table table-bordered table-striped mt-3">
                <thead class="table-light">
                    <tr>
                        <th>#</th>
                        <th>Kode Booking</th>
                        <th>Nama Pelanggan</th>
                        <th>Jumlah Lunas</th>
                        <th>Tanggal Lunas</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- Data akan dimuat dari database di sini -->
                    <tr>
                        <td colspan="6" class="text-center text-secondary">
                            <i class="fas fa-info-circle me-1"></i> Data pembayaran lunas belum dimuat.
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>

        <a href="#" class="btn btn-sm btn-outline-success mt-3">Export ke Excel</a>
    </div>
</div>
