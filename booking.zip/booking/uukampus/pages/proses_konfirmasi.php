<?php
// pages/proses_konfirmasi.php
session_start();
include '../config/konnektingpipel.php';

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== TRUE) {
    header('Location: ../login_admin.php');
    exit();
}

$act = isset($_GET['act']) ? $_GET['act'] : '';
$booking_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$admin_id = $_SESSION['id_admin']; // Ambil ID Admin yang sedang login

if ($booking_id > 0) {
    
    // --- Aksi Terima Konfirmasi DP ---
    if ($act == 'terima') {
        $query = "UPDATE tbl_booking SET
                    status_dp = 'Lunas',
                    status_booking = 'Confirmed',
                    admin_verifikasi_id = $admin_id
                  WHERE booking_id = $booking_id AND status_dp = 'Menunggu'";

        if (mysqli_query($konektion, $query)) {
            $_SESSION['notif'] = ['type' => 'success', 'pesan' => "Konfirmasi DP berhasil! Status booking diubah menjadi **Lunas** dan **Confirmed**."];
        } else {
            $_SESSION['notif'] = ['type' => 'danger', 'pesan' => "Gagal mengkonfirmasi DP: " . mysqli_error($konektion)];
        }
    }
    
    // --- Aksi Tolak Konfirmasi DP ---
    elseif ($act == 'tolak') {
        $query = "UPDATE tbl_booking SET
                    status_dp = 'Ditolak',
                    status_booking = 'Pending',
                    admin_verifikasi_id = $admin_id
                  WHERE booking_id = $booking_id AND status_dp = 'Menunggu'";
        
        if (mysqli_query($konektion, $query)) {
            $_SESSION['notif'] = ['type' => 'warning', 'pesan' => "Konfirmasi DP ditolak. Status pembayaran diubah menjadi **Ditolak**."];
        } else {
            $_SESSION['notif'] = ['type' => 'danger', 'pesan' => "Gagal menolak konfirmasi DP: " . mysqli_error($konektion)];
        }
    }
}

header('Location: konfirmasi_dp.php');
exit();
?>