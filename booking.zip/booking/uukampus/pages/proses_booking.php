<?php
session_start();
include '../config/konnektingpipel.php';

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== TRUE) {
    header('Location: ../login_admin.php');
    exit();
}

$act = isset($_GET['act']) ? $_GET['act'] : '';

// --- Aksi Tambah Data (Create) ---
if ($act == 'tambah') {
    // Ambil data dari form (kolom baru dan lama)
    $nama_penyewa = anti_injection_dan_xss($_POST['nama_penyewa']);
    $penyewa_kontak_wa = anti_injection_dan_xss($_POST['penyewa_kontak_wa']);
    $penyewa_alamat = anti_injection_dan_xss($_POST['penyewa_alamat']);
    $tgl_acara = anti_injection_dan_xss($_POST['tgl_acara']);
    $waktu_mulai = anti_injection_dan_xss($_POST['waktu_mulai']);
    $waktu_selesai = anti_injection_dan_xss($_POST['waktu_selesai']);
    $jenis_acara = anti_injection_dan_xss($_POST['jenis_acara']);
    $total_harga = anti_injection_dan_xss($_POST['total_harga']);
    $status_dp = anti_injection_dan_xss($_POST['status_dp']);
    $status_booking = anti_injection_dan_xss($_POST['status_booking']);
    $notes_admin = anti_injection_dan_xss($_POST['notes_admin']);
    
    // Default/Placeholder untuk kolom yang tidak ada di form:
    $gedung_id = 1; // Default gedung 1
    $user_id = 0; // Default user_id 0 (jika admin yang input)
    $email_penyewa = 'notset@mail.com';
    $kontak_wa = '0'; 

    // Generate Kode Booking Otomatis
    $tahun_bulan = date('Ym');
    $query_count = "SELECT COUNT(*) AS total FROM tbl_booking WHERE DATE_FORMAT(tgl_booking, '%Y%m') = '$tahun_bulan'";
    $data_count = mysqli_fetch_assoc(mysqli_query($konektion, $query_count));
    $nomor_urut = $data_count['total'] + 1;
    $kode_booking = 'BK-' . $tahun_bulan . '-' . str_pad($nomor_urut, 3, '0', STR_PAD_LEFT);

    $query = "INSERT INTO tbl_booking (kode_booking, gedung_id, user_id, nama_penyewa, email_penyewa, penyewa_kontak_wa, penyewa_alamat, kontak_wa, tgl_acara, waktu_mulai, waktu_selesai, jenis_acara, total_harga, status_dp, status_booking, tgl_booking, notes_admin) 
              VALUES ('$kode_booking', '$gedung_id', '$user_id', '$nama_penyewa', '$email_penyewa', '$penyewa_kontak_wa', '$penyewa_alamat', '$kontak_wa', '$tgl_acara', '$waktu_mulai', '$waktu_selesai', '$jenis_acara', '$total_harga', '$status_dp', '$status_booking', NOW(), '$notes_admin')";

    if (mysqli_query($konektion, $query)) {
        $_SESSION['notif'] = ['type' => 'success', 'pesan' => "Data booking **$kode_booking** berhasil ditambahkan!"];
    } else {
        $_SESSION['notif'] = ['type' => 'danger', 'pesan' => "Gagal menambahkan data booking: " . mysqli_error($konektion)];
    }

    header('Location: data_booking.php');
    exit();
}

// --- Aksi Edit Data (Update) ---
elseif ($act == 'edit') {
    $booking_id = (int)$_POST['booking_id']; // Ganti id_booking ke booking_id
    $nama_penyewa = anti_injection_dan_xss($_POST['nama_penyewa']);
    $penyewa_kontak_wa = anti_injection_dan_xss($_POST['penyewa_kontak_wa']);
    $penyewa_alamat = anti_injection_dan_xss($_POST['penyewa_alamat']);
    $tgl_acara = anti_injection_dan_xss($_POST['tgl_acara']);
    $waktu_mulai = anti_injection_dan_xss($_POST['waktu_mulai']);
    $waktu_selesai = anti_injection_dan_xss($_POST['waktu_selesai']);
    $jenis_acara = anti_injection_dan_xss($_POST['jenis_acara']);
    $total_harga = anti_injection_dan_xss($_POST['total_harga']);
    $status_dp = anti_injection_dan_xss($_POST['status_dp']);
    $status_booking = anti_injection_dan_xss($_POST['status_booking']);
    $notes_admin = anti_injection_dan_xss($_POST['notes_admin']);
    
    // Query UPDATE dengan semua kolom baru
    $query = "UPDATE tbl_booking SET
                nama_penyewa = '$nama_penyewa',
                penyewa_kontak_wa = '$penyewa_kontak_wa',
                penyewa_alamat = '$penyewa_alamat',
                tgl_acara = '$tgl_acara',
                waktu_mulai = '$waktu_mulai',
                waktu_selesai = '$waktu_selesai',
                jenis_acara = '$jenis_acara',
                total_harga = '$total_harga',
                status_dp = '$status_dp',
                status_booking = '$status_booking',
                notes_admin = '$notes_admin'
              WHERE booking_id = $booking_id";

    if (mysqli_query($konektion, $query)) {
        $_SESSION['notif'] = ['type' => 'success', 'pesan' => "Data booking berhasil diubah!"];
    } else {
        $_SESSION['notif'] = ['type' => 'danger', 'pesan' => "Gagal mengubah data booking: " . mysqli_error($konektion)];
    }

    header('Location: data_booking.php');
    exit();
}

// --- Aksi Hapus Data (Delete) ---
elseif ($act == 'hapus') {
    $booking_id = (int)$_GET['id'];
    
    // Ganti nama tabel dan kolom ID
    $query = "DELETE FROM tbl_booking WHERE booking_id = $booking_id";
    
    if (mysqli_query($konektion, $query)) {
        $_SESSION['notif'] = ['type' => 'success', 'pesan' => "Data booking berhasil dihapus!"];
    } else {
        $_SESSION['notif'] = ['type' => 'danger', 'pesan' => "Gagal menghapus data booking: " . mysqli_error($konektion)];
    }

    header('Location: data_booking.php');
    exit();
}

else {
    header('Location: data_booking.php');
    exit();
}
?>