<?php
// config/konnektingpipel.php (Revisi variabel koneksi)

$server = "localhost";
$user = "root";
$pass = "";
$database = "db_booking";

// Buat objek koneksi
$konektion = new mysqli($server, $user, $pass, $database);

// Cek koneksi
if ($konektion->connect_error) {
    die("Koneksi gagal: " . $konektion->connect_error);
}

// Set timezone default ke Jakarta (WIB)
date_default_timezone_set('Asia/Jakarta');

// Fungsi untuk mencegah SQL Injection dan Cross-Site Scripting (XSS)
function anti_injection_dan_xss($data) {
    global $konektion; // DIGANTI JADI $konektion
    $filter = stripslashes(strip_tags(htmlspecialchars($data, ENT_QUOTES)));
    return mysqli_real_escape_string($konektion, $filter); // DIGANTI JADI $konektion
}
?>